// SquareLine LVGL GENERATED FILE
// EDITOR VERSION: SquareLine Studio 1.0.1
// LVGL VERSION: 8.2
// PROJECT: FluidNC_Laser

#ifndef _FLUIDNC_LASER_UI_H
#define _FLUIDNC_LASER_UI_H

#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl.h"

extern lv_obj_t * ui_Homescreen;
extern lv_obj_t * ui_Button1;
extern lv_obj_t * ui_Label1;
extern lv_obj_t * ui_Button1_copy;
extern lv_obj_t * ui_Label3;
extern lv_obj_t * ui_Button1_copy_copy;
extern lv_obj_t * ui_Label4;
extern lv_obj_t * ui_Button1_copy1;
extern lv_obj_t * ui_Label5;
extern lv_obj_t * ui_Button1_copy1_copy;
extern lv_obj_t * ui_Label6;
extern lv_obj_t * ui_Button1_copy1_copy_copy;
extern lv_obj_t * ui_Label7;
extern lv_obj_t * ui_Button1_copy2;
extern lv_obj_t * ui_Label8;
extern lv_obj_t * ui_Panel1;
extern lv_obj_t * ui_Label9;
extern lv_obj_t * ui_Panel2;
extern lv_obj_t * ui_Label10;
extern lv_obj_t * ui_Panel1_copy;
extern lv_obj_t * ui_Label11;
extern lv_obj_t * ui_Panel1_copy_copy;
extern lv_obj_t * ui_Label12;
extern lv_obj_t * ui_Panel1_copy_copy_copy;
extern lv_obj_t * ui_Label2;
extern lv_obj_t * ui_Button1_copy1_copy_copy1;
extern lv_obj_t * ui_Label15;
extern lv_obj_t * ui_Label16;
extern lv_obj_t * ui_Button1_copy2_copy;
extern lv_obj_t * ui_Label17;
extern lv_obj_t * ui_Button1_copy_copy_copy;
extern lv_obj_t * ui_Label18;
extern lv_obj_t * ui_Button1_copy_copy_copy_copy;
extern lv_obj_t * ui_Label19;
extern lv_obj_t * ui_Menus;
extern lv_obj_t * ui_ImgButton3_copy_copy1;
extern lv_obj_t * ui_Button2;
extern lv_obj_t * ui_Label20;
extern lv_obj_t * ui_Label29;
extern lv_obj_t * ui_Button2_copy;
extern lv_obj_t * ui_Label43;
extern lv_obj_t * ui_Button2_copy_copy;
extern lv_obj_t * ui_Label44;
extern lv_obj_t * ui_Button2_copy_copy_copy;
extern lv_obj_t * ui_Label45;
extern lv_obj_t * ui_Button5;
extern lv_obj_t * ui_Label46;
extern lv_obj_t * ui_Button5_copy;
extern lv_obj_t * ui_Label47;
extern lv_obj_t * ui_Axis_Settings;
extern lv_obj_t * ui_Switch1;
extern lv_obj_t * ui_Switch2;
extern lv_obj_t * ui_Switch3;
extern lv_obj_t * ui_Switch4;
extern lv_obj_t * ui_Allow_Single_Axis;
extern lv_obj_t * ui_Positive_Direction;
extern lv_obj_t * ui_Soft_Limits_copy_copy;
extern lv_obj_t * ui_Hard_Limits;
extern lv_obj_t * ui_TextArea2;
extern lv_obj_t * ui_TextArea2_copy;
extern lv_obj_t * ui_TextArea2_copy_copy;
extern lv_obj_t * ui_TextArea2_copy_copy_copy;
extern lv_obj_t * ui_TextArea2_copy_copy_copy_copy;
extern lv_obj_t * ui_TextArea2_3;
extern lv_obj_t * ui_TextArea2_2;
extern lv_obj_t * ui_TextArea2_1;
extern lv_obj_t * ui_Label13;
extern lv_obj_t * ui_Label14;
extern lv_obj_t * ui_Label14_copy;
extern lv_obj_t * ui_Label14_copy_copy;
extern lv_obj_t * ui_Label14_copy_copy1;
extern lv_obj_t * ui_Label14_copy1;
extern lv_obj_t * ui_Label14_copy1_copy;
extern lv_obj_t * ui_Label14_copy1_copy_copy;
extern lv_obj_t * ui_Label14_copy1_copy_copy_copy;
extern lv_obj_t * ui_Label21;
extern lv_obj_t * ui_Keyboard2;
extern lv_obj_t * ui_ImgButton3_copy_copy;
extern lv_obj_t * ui_Button6;
extern lv_obj_t * ui_Label51;
extern lv_obj_t * ui_Move_Axis;
extern lv_obj_t * ui_Label22;
extern lv_obj_t * ui_Button3;
extern lv_obj_t * ui_Label23;
extern lv_obj_t * ui_Button3_copy;
extern lv_obj_t * ui_Label24;
extern lv_obj_t * ui_Button3_copy1;
extern lv_obj_t * ui_Label25;
extern lv_obj_t * ui_Button3_copy1_copy;
extern lv_obj_t * ui_Label26;
extern lv_obj_t * ui_Button3_copy_copy;
extern lv_obj_t * ui_Label27;
extern lv_obj_t * ui_Button3_copy_copy_copy;
extern lv_obj_t * ui_Label28;
extern lv_obj_t * ui_Switch5;
extern lv_obj_t * ui_Label30;
extern lv_obj_t * ui_Button4;
extern lv_obj_t * ui_Label31;
extern lv_obj_t * ui_Button4_1;
extern lv_obj_t * ui_Label32;
extern lv_obj_t * ui_Button4_2;
extern lv_obj_t * ui_Label33;
extern lv_obj_t * ui_Button4_copy_copy_copy;
extern lv_obj_t * ui_Label34;
extern lv_obj_t * ui_Button4_5;
extern lv_obj_t * ui_Label35;
extern lv_obj_t * ui_Button4_copy_copy_copy_copy_copy;
extern lv_obj_t * ui_Label36;
extern lv_obj_t * ui_Label37;
extern lv_obj_t * ui_Label37_copy;
extern lv_obj_t * ui_Label37_copy1;
extern lv_obj_t * ui_Button4_2_copy;
extern lv_obj_t * ui_Label38;
extern lv_obj_t * ui_Button4_2_copy_copy;
extern lv_obj_t * ui_Label39;
extern lv_obj_t * ui_Label40;
extern lv_obj_t * ui_Label41;
extern lv_obj_t * ui_Label42;
extern lv_obj_t * ui_ImgButton3;
extern lv_obj_t * ui_SD_Print;
extern lv_obj_t * ui_Label22_copy1;
extern lv_obj_t * ui_Panel3;
extern lv_obj_t * ui_ImgButton3_copy;
extern lv_obj_t * ui_up;
extern lv_obj_t * ui_Label49;
extern lv_obj_t * ui_down;
extern lv_obj_t * ui_Label50;
extern lv_obj_t * ui_print;
extern lv_obj_t * ui_Label48;

void restart_esp(lv_event_t * e);
void home_x(lv_event_t * e);
void home_y(lv_event_t * e);
void home_all(lv_event_t * e);
void alarm_reset(lv_event_t * e);
void home_all(lv_event_t * e);

LV_IMG_DECLARE(ui_img_home_40x42_png);    // assets\home_40x42.png
LV_IMG_DECLARE(ui_img_back1_png);    // assets\back1.png




void ui_init(void);

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif
