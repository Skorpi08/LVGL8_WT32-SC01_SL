// SquareLine LVGL GENERATED FILE
// EDITOR VERSION: SquareLine Studio 1.0.1
// LVGL VERSION: 8.2
// PROJECT: FluidNC_Laser

#include "ui.h"
#include "ui_helpers.h"

///////////////////// VARIABLES ////////////////////
lv_obj_t * ui_Homescreen;
lv_obj_t * ui_Button1;
lv_obj_t * ui_Label1;
lv_obj_t * ui_Button1_copy;
lv_obj_t * ui_Label3;
lv_obj_t * ui_Button1_copy_copy;
lv_obj_t * ui_Label4;
lv_obj_t * ui_Button1_copy1;
lv_obj_t * ui_Label5;
lv_obj_t * ui_Button1_copy1_copy;
lv_obj_t * ui_Label6;
lv_obj_t * ui_Button1_copy1_copy_copy;
lv_obj_t * ui_Label7;
lv_obj_t * ui_Button1_copy2;
lv_obj_t * ui_Label8;
lv_obj_t * ui_Panel1;
lv_obj_t * ui_Label9;
lv_obj_t * ui_Panel2;
lv_obj_t * ui_Label10;
lv_obj_t * ui_Panel1_copy;
lv_obj_t * ui_Label11;
lv_obj_t * ui_Panel1_copy_copy;
lv_obj_t * ui_Label12;
lv_obj_t * ui_Panel1_copy_copy_copy;
lv_obj_t * ui_Label2;
lv_obj_t * ui_Button1_copy1_copy_copy1;
lv_obj_t * ui_Label15;
lv_obj_t * ui_Label16;
lv_obj_t * ui_Button1_copy2_copy;
lv_obj_t * ui_Label17;
lv_obj_t * ui_Button1_copy_copy_copy;
lv_obj_t * ui_Label18;
lv_obj_t * ui_Button1_copy_copy_copy_copy;
lv_obj_t * ui_Label19;
lv_obj_t * ui_Menus;
lv_obj_t * ui_ImgButton3_copy_copy1;
lv_obj_t * ui_Button2;
lv_obj_t * ui_Label20;
lv_obj_t * ui_Label29;
lv_obj_t * ui_Button2_copy;
lv_obj_t * ui_Label43;
lv_obj_t * ui_Button2_copy_copy;
lv_obj_t * ui_Label44;
lv_obj_t * ui_Button2_copy_copy_copy;
lv_obj_t * ui_Label45;
lv_obj_t * ui_Button5;
lv_obj_t * ui_Label46;
lv_obj_t * ui_Button5_copy;
lv_obj_t * ui_Label47;
lv_obj_t * ui_Axis_Settings;
lv_obj_t * ui_Switch1;
lv_obj_t * ui_Switch2;
lv_obj_t * ui_Switch3;
lv_obj_t * ui_Switch4;
lv_obj_t * ui_Allow_Single_Axis;
lv_obj_t * ui_Positive_Direction;
lv_obj_t * ui_Soft_Limits_copy_copy;
lv_obj_t * ui_Hard_Limits;
lv_obj_t * ui_TextArea2;
lv_obj_t * ui_TextArea2_copy;
lv_obj_t * ui_TextArea2_copy_copy;
lv_obj_t * ui_TextArea2_copy_copy_copy;
lv_obj_t * ui_TextArea2_copy_copy_copy_copy;
lv_obj_t * ui_TextArea2_3;
lv_obj_t * ui_TextArea2_2;
lv_obj_t * ui_TextArea2_1;
lv_obj_t * ui_Label13;
lv_obj_t * ui_Label14;
lv_obj_t * ui_Label14_copy;
lv_obj_t * ui_Label14_copy_copy;
lv_obj_t * ui_Label14_copy_copy1;
lv_obj_t * ui_Label14_copy1;
lv_obj_t * ui_Label14_copy1_copy;
lv_obj_t * ui_Label14_copy1_copy_copy;
lv_obj_t * ui_Label14_copy1_copy_copy_copy;
lv_obj_t * ui_Label21;
lv_obj_t * ui_Keyboard2;
lv_obj_t * ui_ImgButton3_copy_copy;
lv_obj_t * ui_Button6;
lv_obj_t * ui_Label51;
lv_obj_t * ui_Move_Axis;
lv_obj_t * ui_Label22;
lv_obj_t * ui_Button3;
lv_obj_t * ui_Label23;
lv_obj_t * ui_Button3_copy;
lv_obj_t * ui_Label24;
lv_obj_t * ui_Button3_copy1;
lv_obj_t * ui_Label25;
lv_obj_t * ui_Button3_copy1_copy;
lv_obj_t * ui_Label26;
lv_obj_t * ui_Button3_copy_copy;
lv_obj_t * ui_Label27;
lv_obj_t * ui_Button3_copy_copy_copy;
lv_obj_t * ui_Label28;
lv_obj_t * ui_Switch5;
lv_obj_t * ui_Label30;
lv_obj_t * ui_Button4;
lv_obj_t * ui_Label31;
lv_obj_t * ui_Button4_1;
lv_obj_t * ui_Label32;
lv_obj_t * ui_Button4_2;
lv_obj_t * ui_Label33;
lv_obj_t * ui_Button4_copy_copy_copy;
lv_obj_t * ui_Label34;
lv_obj_t * ui_Button4_5;
lv_obj_t * ui_Label35;
lv_obj_t * ui_Button4_copy_copy_copy_copy_copy;
lv_obj_t * ui_Label36;
lv_obj_t * ui_Label37;
lv_obj_t * ui_Label37_copy;
lv_obj_t * ui_Label37_copy1;
lv_obj_t * ui_Button4_2_copy;
lv_obj_t * ui_Label38;
lv_obj_t * ui_Button4_2_copy_copy;
lv_obj_t * ui_Label39;
lv_obj_t * ui_Label40;
lv_obj_t * ui_Label41;
lv_obj_t * ui_Label42;
lv_obj_t * ui_ImgButton3;
lv_obj_t * ui_SD_Print;
lv_obj_t * ui_Label22_copy1;
lv_obj_t * ui_Panel3;
lv_obj_t * ui_ImgButton3_copy;
lv_obj_t * ui_up;
lv_obj_t * ui_Label49;
lv_obj_t * ui_down;
lv_obj_t * ui_Label50;
lv_obj_t * ui_print;
lv_obj_t * ui_Label48;

///////////////////// ANIMATIONS ////////////////////

///////////////////// FUNCTIONS ////////////////////
static void ui_event_Button1_copy_copy(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        restart_esp(e);
    }
}
static void ui_event_Button1_copy1(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        home_x(e);
    }
}
static void ui_event_Button1_copy1_copy_copy(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        home_y(e);
    }
}
static void ui_event_Button1_copy2(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        home_all(e);
    }
}
static void ui_event_Panel2(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        alarm_reset(e);
    }
}
static void ui_event_Label10(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
}
static void ui_event_Button1_copy2_copy(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        home_all(e);
    }
}
static void ui_event_Button1_copy_copy_copy(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        _ui_screen_change(ui_Axis_Settings, LV_SCR_LOAD_ANIM_FADE_ON, 0, 0);
    }
}
static void ui_event_Button1_copy_copy_copy_copy(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        _ui_screen_change(ui_Menus, LV_SCR_LOAD_ANIM_FADE_ON, 100, 0);
    }
}
static void ui_event_ImgButton3_copy_copy1(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        _ui_screen_change(ui_Homescreen, LV_SCR_LOAD_ANIM_FADE_ON, 500, 0);
    }
}
static void ui_event_Button2(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        _ui_screen_change(ui_Axis_Settings, LV_SCR_LOAD_ANIM_FADE_ON, 100, 0);
        _ui_label_set_property(ui_Label13, _UI_LABEL_PROPERTY_TEXT, "X Axis Settings");
    }
}
static void ui_event_Button2_copy(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        _ui_screen_change(ui_Axis_Settings, LV_SCR_LOAD_ANIM_FADE_ON, 100, 0);
        _ui_label_set_property(ui_Label13, _UI_LABEL_PROPERTY_TEXT, "Y Axis Settings");
    }
}
static void ui_event_Button2_copy_copy(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        _ui_screen_change(ui_Axis_Settings, LV_SCR_LOAD_ANIM_FADE_ON, 100, 0);
        _ui_label_set_property(ui_Label13, _UI_LABEL_PROPERTY_TEXT, "Z Axis Settings");
    }
}
static void ui_event_Button2_copy_copy_copy(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        _ui_screen_change(ui_Axis_Settings, LV_SCR_LOAD_ANIM_FADE_ON, 100, 0);
        _ui_label_set_property(ui_Label13, _UI_LABEL_PROPERTY_TEXT, "A Axis Settings");
    }
}
static void ui_event_Button5(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        _ui_screen_change(ui_Move_Axis, LV_SCR_LOAD_ANIM_FADE_ON, 100, 0);
    }
}
static void ui_event_Button5_copy(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        _ui_screen_change(ui_SD_Print, LV_SCR_LOAD_ANIM_FADE_ON, 100, 0);
    }
}
static void ui_event_Axis_Settings(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        _ui_flag_modify(ui_Keyboard2, LV_OBJ_FLAG_HIDDEN, _UI_MODIFY_FLAG_ADD);
    }
}
static void ui_event_TextArea2(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        _ui_flag_modify(ui_Keyboard2, LV_OBJ_FLAG_HIDDEN, _UI_MODIFY_FLAG_REMOVE);
    }
}
static void ui_event_TextArea2_copy(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
}
static void ui_event_TextArea2_copy_copy(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
}
static void ui_event_TextArea2_copy_copy_copy(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
}
static void ui_event_TextArea2_copy_copy_copy_copy(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
}
static void ui_event_TextArea2_3(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
}
static void ui_event_TextArea2_2(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
}
static void ui_event_TextArea2_1(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
}
static void ui_event_ImgButton3_copy_copy(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        _ui_screen_change(ui_Menus, LV_SCR_LOAD_ANIM_FADE_ON, 100, 0);
        _ui_label_set_property(ui_Label51, _UI_LABEL_PROPERTY_TEXT, "Save");
        _ui_flag_modify(ui_Keyboard2, LV_OBJ_FLAG_HIDDEN, _UI_MODIFY_FLAG_ADD);
    }
}
static void ui_event_Button6(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        _ui_label_set_property(ui_Label51, _UI_LABEL_PROPERTY_TEXT, "Saved");
    }
}
static void ui_event_ImgButton3(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        _ui_screen_change(ui_Menus, LV_SCR_LOAD_ANIM_FADE_ON, 100, 0);
    }
}
static void ui_event_ImgButton3_copy(lv_event_t * e)
{
    lv_event_code_t event = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e);
    if(event == LV_EVENT_CLICKED) {
        _ui_screen_change(ui_Menus, LV_SCR_LOAD_ANIM_FADE_ON, 100, 0);
    }
}

///////////////////// SCREENS ////////////////////
void ui_Homescreen_screen_init(void)
{

    // Homescreen

    ui_Homescreen = lv_obj_create(NULL);

    lv_obj_clear_flag(ui_Homescreen, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_set_style_bg_color(ui_Homescreen, lv_color_hex(0x3C00FF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Homescreen, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Button1

    ui_Button1 = lv_btn_create(ui_Homescreen);

    lv_obj_set_width(ui_Button1, 100);
    lv_obj_set_height(ui_Button1, 50);

    lv_obj_set_x(ui_Button1, -49);
    lv_obj_set_y(ui_Button1, 107);

    lv_obj_set_align(ui_Button1, LV_ALIGN_CENTER);

    lv_obj_add_flag(ui_Button1, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button1, LV_OBJ_FLAG_SCROLLABLE);

    // Label1

    ui_Label1 = lv_label_create(ui_Button1);

    lv_obj_set_width(ui_Label1, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label1, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label1, 0);
    lv_obj_set_y(ui_Label1, 0);

    lv_obj_set_align(ui_Label1, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label1, "Start");

    // Button1_copy

    ui_Button1_copy = lv_btn_create(ui_Homescreen);

    lv_obj_set_width(ui_Button1_copy, 100);
    lv_obj_set_height(ui_Button1_copy, 50);

    lv_obj_set_x(ui_Button1_copy, 63);
    lv_obj_set_y(ui_Button1_copy, 107);

    lv_obj_set_align(ui_Button1_copy, LV_ALIGN_CENTER);

    lv_obj_add_flag(ui_Button1_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button1_copy, LV_OBJ_FLAG_SCROLLABLE);

    // Label3

    ui_Label3 = lv_label_create(ui_Button1_copy);

    lv_obj_set_width(ui_Label3, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label3, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label3, 0);
    lv_obj_set_y(ui_Label3, 0);

    lv_obj_set_align(ui_Label3, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label3, "Hold");

    // Button1_copy_copy

    ui_Button1_copy_copy = lv_btn_create(ui_Homescreen);

    lv_obj_set_width(ui_Button1_copy_copy, 100);
    lv_obj_set_height(ui_Button1_copy_copy, 50);

    lv_obj_set_x(ui_Button1_copy_copy, 175);
    lv_obj_set_y(ui_Button1_copy_copy, 107);

    lv_obj_set_align(ui_Button1_copy_copy, LV_ALIGN_CENTER);

    lv_obj_add_flag(ui_Button1_copy_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button1_copy_copy, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_add_event_cb(ui_Button1_copy_copy, ui_event_Button1_copy_copy, LV_EVENT_ALL, NULL);

    // Label4

    ui_Label4 = lv_label_create(ui_Button1_copy_copy);

    lv_obj_set_width(ui_Label4, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label4, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label4, 0);
    lv_obj_set_y(ui_Label4, 0);

    lv_obj_set_align(ui_Label4, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label4, "Restart");

    // Button1_copy1

    ui_Button1_copy1 = lv_btn_create(ui_Homescreen);

    lv_obj_set_width(ui_Button1_copy1, 60);
    lv_obj_set_height(ui_Button1_copy1, 50);

    lv_obj_set_x(ui_Button1_copy1, 15);
    lv_obj_set_y(ui_Button1_copy1, 115);

    lv_obj_add_flag(ui_Button1_copy1, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button1_copy1, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_add_event_cb(ui_Button1_copy1, ui_event_Button1_copy1, LV_EVENT_ALL, NULL);
    lv_obj_set_style_bg_img_src(ui_Button1_copy1, &ui_img_home_40x42_png, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_img_recolor(ui_Button1_copy1, lv_color_hex(0xFF0000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_img_recolor_opa(ui_Button1_copy1, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Label5

    ui_Label5 = lv_label_create(ui_Button1_copy1);

    lv_obj_set_width(ui_Label5, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label5, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label5, 0);
    lv_obj_set_y(ui_Label5, 7);

    lv_obj_set_align(ui_Label5, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label5, "X");

    lv_obj_set_style_text_color(ui_Label5, lv_color_hex(0x00FF2B), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_Label5, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_Label5, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Button1_copy1_copy

    ui_Button1_copy1_copy = lv_btn_create(ui_Homescreen);

    lv_obj_set_width(ui_Button1_copy1_copy, 60);
    lv_obj_set_height(ui_Button1_copy1_copy, 50);

    lv_obj_set_x(ui_Button1_copy1_copy, 256);
    lv_obj_set_y(ui_Button1_copy1_copy, 115);

    lv_obj_add_flag(ui_Button1_copy1_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button1_copy1_copy, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_set_style_bg_img_src(ui_Button1_copy1_copy, &ui_img_home_40x42_png, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Label6

    ui_Label6 = lv_label_create(ui_Button1_copy1_copy);

    lv_obj_set_width(ui_Label6, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label6, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label6, 0);
    lv_obj_set_y(ui_Label6, 7);

    lv_obj_set_align(ui_Label6, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label6, "Z");

    lv_obj_set_style_text_color(ui_Label6, lv_color_hex(0x00FF2B), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_Label6, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_Label6, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Button1_copy1_copy_copy

    ui_Button1_copy1_copy_copy = lv_btn_create(ui_Homescreen);

    lv_obj_set_width(ui_Button1_copy1_copy_copy, 60);
    lv_obj_set_height(ui_Button1_copy1_copy_copy, 50);

    lv_obj_set_x(ui_Button1_copy1_copy_copy, 14);
    lv_obj_set_y(ui_Button1_copy1_copy_copy, 179);

    lv_obj_add_flag(ui_Button1_copy1_copy_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button1_copy1_copy_copy, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_add_event_cb(ui_Button1_copy1_copy_copy, ui_event_Button1_copy1_copy_copy, LV_EVENT_ALL, NULL);
    lv_obj_set_style_bg_img_src(ui_Button1_copy1_copy_copy, &ui_img_home_40x42_png, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_img_recolor(ui_Button1_copy1_copy_copy, lv_color_hex(0x0007FF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_img_recolor_opa(ui_Button1_copy1_copy_copy, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Label7

    ui_Label7 = lv_label_create(ui_Button1_copy1_copy_copy);

    lv_obj_set_width(ui_Label7, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label7, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label7, 0);
    lv_obj_set_y(ui_Label7, 7);

    lv_obj_set_align(ui_Label7, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label7, "Y");

    lv_obj_set_style_text_color(ui_Label7, lv_color_hex(0x00FF2B), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_Label7, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_Label7, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Button1_copy2

    ui_Button1_copy2 = lv_btn_create(ui_Homescreen);

    lv_obj_set_width(ui_Button1_copy2, 80);
    lv_obj_set_height(ui_Button1_copy2, 51);

    lv_obj_set_x(ui_Button1_copy2, 15);
    lv_obj_set_y(ui_Button1_copy2, 46);

    lv_obj_add_flag(ui_Button1_copy2, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button1_copy2, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_add_event_cb(ui_Button1_copy2, ui_event_Button1_copy2, LV_EVENT_ALL, NULL);

    // Label8

    ui_Label8 = lv_label_create(ui_Button1_copy2);

    lv_obj_set_width(ui_Label8, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label8, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label8, 0);
    lv_obj_set_y(ui_Label8, 0);

    lv_obj_set_align(ui_Label8, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label8, "Home\n   all");

    // Panel1

    ui_Panel1 = lv_obj_create(ui_Homescreen);

    lv_obj_set_width(ui_Panel1, 137);
    lv_obj_set_height(ui_Panel1, 50);

    lv_obj_set_x(ui_Panel1, -82);
    lv_obj_set_y(ui_Panel1, -20);

    lv_obj_set_align(ui_Panel1, LV_ALIGN_CENTER);

    lv_obj_clear_flag(ui_Panel1, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_set_style_bg_color(ui_Panel1, lv_color_hex(0x00E2FF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Panel1, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Label9

    ui_Label9 = lv_label_create(ui_Panel1);

    lv_obj_set_width(ui_Label9, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label9, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label9, 0);
    lv_obj_set_y(ui_Label9, 0);

    lv_obj_set_align(ui_Label9, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label9, "325.000");

    lv_obj_set_style_text_color(ui_Label9, lv_color_hex(0xFF0000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_Label9, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_Label9, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Panel2

    ui_Panel2 = lv_obj_create(ui_Homescreen);

    lv_obj_set_width(ui_Panel2, 121);
    lv_obj_set_height(ui_Panel2, 50);

    lv_obj_set_x(ui_Panel2, -169);
    lv_obj_set_y(ui_Panel2, 107);

    lv_obj_set_align(ui_Panel2, LV_ALIGN_CENTER);

    lv_obj_clear_flag(ui_Panel2, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_add_event_cb(ui_Panel2, ui_event_Panel2, LV_EVENT_ALL, NULL);
    lv_obj_set_style_bg_color(ui_Panel2, lv_color_hex(0xFF0000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Panel2, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_color(ui_Panel2, lv_color_hex(0x16FF00), LV_PART_MAIN | LV_STATE_DEFAULT);

    // Label10

    ui_Label10 = lv_label_create(ui_Panel2);

    lv_obj_set_width(ui_Label10, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label10, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label10, 0);
    lv_obj_set_y(ui_Label10, 0);

    lv_obj_set_align(ui_Label10, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label10, "Alarm");

    lv_obj_add_event_cb(ui_Label10, ui_event_Label10, LV_EVENT_ALL, NULL);
    lv_obj_set_style_text_color(ui_Label10, lv_color_hex(0xFFFFFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_Label10, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_Label10, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Panel1_copy

    ui_Panel1_copy = lv_obj_create(ui_Homescreen);

    lv_obj_set_width(ui_Panel1_copy, 137);
    lv_obj_set_height(ui_Panel1_copy, 50);

    lv_obj_set_x(ui_Panel1_copy, -82);
    lv_obj_set_y(ui_Panel1_copy, 44);

    lv_obj_set_align(ui_Panel1_copy, LV_ALIGN_CENTER);

    lv_obj_clear_flag(ui_Panel1_copy, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_set_style_bg_color(ui_Panel1_copy, lv_color_hex(0x00E2FF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Panel1_copy, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Label11

    ui_Label11 = lv_label_create(ui_Panel1_copy);

    lv_obj_set_width(ui_Label11, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label11, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label11, 0);
    lv_obj_set_y(ui_Label11, 0);

    lv_obj_set_align(ui_Label11, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label11, "325.000");

    lv_obj_set_style_text_color(ui_Label11, lv_color_hex(0xFF0000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_Label11, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_Label11, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Panel1_copy_copy

    ui_Panel1_copy_copy = lv_obj_create(ui_Homescreen);

    lv_obj_set_width(ui_Panel1_copy_copy, 137);
    lv_obj_set_height(ui_Panel1_copy_copy, 50);

    lv_obj_set_x(ui_Panel1_copy_copy, 160);
    lv_obj_set_y(ui_Panel1_copy_copy, -21);

    lv_obj_set_align(ui_Panel1_copy_copy, LV_ALIGN_CENTER);

    lv_obj_clear_flag(ui_Panel1_copy_copy, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_set_style_bg_color(ui_Panel1_copy_copy, lv_color_hex(0x00E2FF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Panel1_copy_copy, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Label12

    ui_Label12 = lv_label_create(ui_Panel1_copy_copy);

    lv_obj_set_width(ui_Label12, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label12, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label12, 0);
    lv_obj_set_y(ui_Label12, 0);

    lv_obj_set_align(ui_Label12, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label12, "325.000");

    lv_obj_set_style_text_color(ui_Label12, lv_color_hex(0xFF0000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_Label12, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_Label12, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Panel1_copy_copy_copy

    ui_Panel1_copy_copy_copy = lv_obj_create(ui_Homescreen);

    lv_obj_set_width(ui_Panel1_copy_copy_copy, 137);
    lv_obj_set_height(ui_Panel1_copy_copy_copy, 50);

    lv_obj_set_x(ui_Panel1_copy_copy_copy, 161);
    lv_obj_set_y(ui_Panel1_copy_copy_copy, 44);

    lv_obj_set_align(ui_Panel1_copy_copy_copy, LV_ALIGN_CENTER);

    lv_obj_clear_flag(ui_Panel1_copy_copy_copy, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_set_style_bg_color(ui_Panel1_copy_copy_copy, lv_color_hex(0x00E2FF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Panel1_copy_copy_copy, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Label2

    ui_Label2 = lv_label_create(ui_Panel1_copy_copy_copy);

    lv_obj_set_width(ui_Label2, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label2, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label2, 0);
    lv_obj_set_y(ui_Label2, 0);

    lv_obj_set_align(ui_Label2, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label2, "325.000");

    lv_obj_set_style_text_color(ui_Label2, lv_color_hex(0xFF0000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_Label2, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_Label2, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Button1_copy1_copy_copy1

    ui_Button1_copy1_copy_copy1 = lv_btn_create(ui_Homescreen);

    lv_obj_set_width(ui_Button1_copy1_copy_copy1, 60);
    lv_obj_set_height(ui_Button1_copy1_copy_copy1, 50);

    lv_obj_set_x(ui_Button1_copy1_copy_copy1, 257);
    lv_obj_set_y(ui_Button1_copy1_copy_copy1, 178);

    lv_obj_add_flag(ui_Button1_copy1_copy_copy1, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button1_copy1_copy_copy1, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_set_style_bg_img_src(ui_Button1_copy1_copy_copy1, &ui_img_home_40x42_png, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Label15

    ui_Label15 = lv_label_create(ui_Button1_copy1_copy_copy1);

    lv_obj_set_width(ui_Label15, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label15, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label15, 0);
    lv_obj_set_y(ui_Label15, 7);

    lv_obj_set_align(ui_Label15, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label15, "A");

    lv_obj_set_style_text_color(ui_Label15, lv_color_hex(0x00FF2B), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_Label15, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_Label15, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Label16

    ui_Label16 = lv_label_create(ui_Homescreen);

    lv_obj_set_width(ui_Label16, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label16, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label16, 0);
    lv_obj_set_y(ui_Label16, 1);

    lv_obj_set_align(ui_Label16, LV_ALIGN_TOP_MID);

    lv_label_set_text(ui_Label16, "Homescreen");

    lv_obj_set_style_text_color(ui_Label16, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_Label16, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_Label16, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Button1_copy2_copy

    ui_Button1_copy2_copy = lv_btn_create(ui_Homescreen);

    lv_obj_set_width(ui_Button1_copy2_copy, 80);
    lv_obj_set_height(ui_Button1_copy2_copy, 51);

    lv_obj_set_x(ui_Button1_copy2_copy, 123);
    lv_obj_set_y(ui_Button1_copy2_copy, 47);

    lv_obj_add_flag(ui_Button1_copy2_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button1_copy2_copy, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_add_event_cb(ui_Button1_copy2_copy, ui_event_Button1_copy2_copy, LV_EVENT_ALL, NULL);

    // Label17

    ui_Label17 = lv_label_create(ui_Button1_copy2_copy);

    lv_obj_set_width(ui_Label17, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label17, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label17, 0);
    lv_obj_set_y(ui_Label17, 0);

    lv_obj_set_align(ui_Label17, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label17, "Motors\n    off");

    // Button1_copy_copy_copy

    ui_Button1_copy_copy_copy = lv_btn_create(ui_Homescreen);

    lv_obj_set_width(ui_Button1_copy_copy_copy, 100);
    lv_obj_set_height(ui_Button1_copy_copy_copy, 50);

    lv_obj_set_x(ui_Button1_copy_copy_copy, 175);
    lv_obj_set_y(ui_Button1_copy_copy_copy, -87);

    lv_obj_set_align(ui_Button1_copy_copy_copy, LV_ALIGN_CENTER);

    lv_obj_add_flag(ui_Button1_copy_copy_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button1_copy_copy_copy, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_add_event_cb(ui_Button1_copy_copy_copy, ui_event_Button1_copy_copy_copy, LV_EVENT_ALL, NULL);

    // Label18

    ui_Label18 = lv_label_create(ui_Button1_copy_copy_copy);

    lv_obj_set_width(ui_Label18, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label18, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label18, 0);
    lv_obj_set_y(ui_Label18, 0);

    lv_obj_set_align(ui_Label18, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label18, "Settings");

    // Button1_copy_copy_copy_copy

    ui_Button1_copy_copy_copy_copy = lv_btn_create(ui_Homescreen);

    lv_obj_set_width(ui_Button1_copy_copy_copy_copy, 100);
    lv_obj_set_height(ui_Button1_copy_copy_copy_copy, 50);

    lv_obj_set_x(ui_Button1_copy_copy_copy_copy, 46);
    lv_obj_set_y(ui_Button1_copy_copy_copy_copy, -88);

    lv_obj_set_align(ui_Button1_copy_copy_copy_copy, LV_ALIGN_CENTER);

    lv_obj_add_flag(ui_Button1_copy_copy_copy_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button1_copy_copy_copy_copy, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_add_event_cb(ui_Button1_copy_copy_copy_copy, ui_event_Button1_copy_copy_copy_copy, LV_EVENT_ALL, NULL);

    // Label19

    ui_Label19 = lv_label_create(ui_Button1_copy_copy_copy_copy);

    lv_obj_set_width(ui_Label19, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label19, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label19, 0);
    lv_obj_set_y(ui_Label19, 0);

    lv_obj_set_align(ui_Label19, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label19, "Menu");

}
void ui_Menus_screen_init(void)
{

    // Menus

    ui_Menus = lv_obj_create(NULL);

    lv_obj_clear_flag(ui_Menus, LV_OBJ_FLAG_SCROLLABLE);

    // ImgButton3_copy_copy1

    ui_ImgButton3_copy_copy1 = lv_imgbtn_create(ui_Menus);
    lv_imgbtn_set_src(ui_ImgButton3_copy_copy1, LV_IMGBTN_STATE_RELEASED, NULL, &ui_img_back1_png, NULL);
    lv_imgbtn_set_src(ui_ImgButton3_copy_copy1, LV_IMGBTN_STATE_PRESSED, NULL, &ui_img_back1_png, NULL);

    lv_obj_set_height(ui_ImgButton3_copy_copy1, 64);
    lv_obj_set_width(ui_ImgButton3_copy_copy1, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_ImgButton3_copy_copy1, 8);
    lv_obj_set_y(ui_ImgButton3_copy_copy1, 8);

    lv_obj_add_event_cb(ui_ImgButton3_copy_copy1, ui_event_ImgButton3_copy_copy1, LV_EVENT_ALL, NULL);

    // Button2

    ui_Button2 = lv_btn_create(ui_Menus);

    lv_obj_set_width(ui_Button2, 119);
    lv_obj_set_height(ui_Button2, 50);

    lv_obj_set_x(ui_Button2, 345);
    lv_obj_set_y(ui_Button2, 59);

    lv_obj_add_flag(ui_Button2, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button2, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_add_event_cb(ui_Button2, ui_event_Button2, LV_EVENT_ALL, NULL);

    // Label20

    ui_Label20 = lv_label_create(ui_Button2);

    lv_obj_set_width(ui_Label20, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label20, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label20, 0);
    lv_obj_set_y(ui_Label20, 0);

    lv_obj_set_align(ui_Label20, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label20, "X Axis Settings");

    // Label29

    ui_Label29 = lv_label_create(ui_Menus);

    lv_obj_set_width(ui_Label29, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label29, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label29, 0);
    lv_obj_set_y(ui_Label29, 1);

    lv_obj_set_align(ui_Label29, LV_ALIGN_TOP_MID);

    lv_label_set_text(ui_Label29, "Menu");

    lv_obj_set_style_text_font(ui_Label29, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Button2_copy

    ui_Button2_copy = lv_btn_create(ui_Menus);

    lv_obj_set_width(ui_Button2_copy, 119);
    lv_obj_set_height(ui_Button2_copy, 50);

    lv_obj_set_x(ui_Button2_copy, 346);
    lv_obj_set_y(ui_Button2_copy, 119);

    lv_obj_add_flag(ui_Button2_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button2_copy, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_add_event_cb(ui_Button2_copy, ui_event_Button2_copy, LV_EVENT_ALL, NULL);

    // Label43

    ui_Label43 = lv_label_create(ui_Button2_copy);

    lv_obj_set_width(ui_Label43, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label43, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label43, 0);
    lv_obj_set_y(ui_Label43, 0);

    lv_obj_set_align(ui_Label43, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label43, "Y Axis Settings");

    // Button2_copy_copy

    ui_Button2_copy_copy = lv_btn_create(ui_Menus);

    lv_obj_set_width(ui_Button2_copy_copy, 119);
    lv_obj_set_height(ui_Button2_copy_copy, 50);

    lv_obj_set_x(ui_Button2_copy_copy, 346);
    lv_obj_set_y(ui_Button2_copy_copy, 180);

    lv_obj_add_flag(ui_Button2_copy_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button2_copy_copy, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_add_event_cb(ui_Button2_copy_copy, ui_event_Button2_copy_copy, LV_EVENT_ALL, NULL);

    // Label44

    ui_Label44 = lv_label_create(ui_Button2_copy_copy);

    lv_obj_set_width(ui_Label44, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label44, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label44, 0);
    lv_obj_set_y(ui_Label44, 0);

    lv_obj_set_align(ui_Label44, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label44, "Z Axis Settings");

    // Button2_copy_copy_copy

    ui_Button2_copy_copy_copy = lv_btn_create(ui_Menus);

    lv_obj_set_width(ui_Button2_copy_copy_copy, 119);
    lv_obj_set_height(ui_Button2_copy_copy_copy, 50);

    lv_obj_set_x(ui_Button2_copy_copy_copy, 347);
    lv_obj_set_y(ui_Button2_copy_copy_copy, 240);

    lv_obj_add_flag(ui_Button2_copy_copy_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button2_copy_copy_copy, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_add_event_cb(ui_Button2_copy_copy_copy, ui_event_Button2_copy_copy_copy, LV_EVENT_ALL, NULL);

    // Label45

    ui_Label45 = lv_label_create(ui_Button2_copy_copy_copy);

    lv_obj_set_width(ui_Label45, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label45, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label45, 0);
    lv_obj_set_y(ui_Label45, 0);

    lv_obj_set_align(ui_Label45, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label45, "A Axis Settings");

    // Button5

    ui_Button5 = lv_btn_create(ui_Menus);

    lv_obj_set_width(ui_Button5, 100);
    lv_obj_set_height(ui_Button5, 50);

    lv_obj_set_x(ui_Button5, 19);
    lv_obj_set_y(ui_Button5, -16);

    lv_obj_set_align(ui_Button5, LV_ALIGN_CENTER);

    lv_obj_add_flag(ui_Button5, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button5, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_add_event_cb(ui_Button5, ui_event_Button5, LV_EVENT_ALL, NULL);

    // Label46

    ui_Label46 = lv_label_create(ui_Button5);

    lv_obj_set_width(ui_Label46, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label46, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label46, 0);
    lv_obj_set_y(ui_Label46, 0);

    lv_obj_set_align(ui_Label46, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label46, "Move Axis");

    // Button5_copy

    ui_Button5_copy = lv_btn_create(ui_Menus);

    lv_obj_set_width(ui_Button5_copy, 100);
    lv_obj_set_height(ui_Button5_copy, 50);

    lv_obj_set_x(ui_Button5_copy, 17);
    lv_obj_set_y(ui_Button5_copy, -77);

    lv_obj_set_align(ui_Button5_copy, LV_ALIGN_CENTER);

    lv_obj_add_flag(ui_Button5_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button5_copy, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_add_event_cb(ui_Button5_copy, ui_event_Button5_copy, LV_EVENT_ALL, NULL);

    // Label47

    ui_Label47 = lv_label_create(ui_Button5_copy);

    lv_obj_set_width(ui_Label47, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label47, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label47, 0);
    lv_obj_set_y(ui_Label47, 0);

    lv_obj_set_align(ui_Label47, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label47, "SD Card");

}
void ui_Axis_Settings_screen_init(void)
{

    // Axis_Settings

    ui_Axis_Settings = lv_obj_create(NULL);

    lv_obj_clear_flag(ui_Axis_Settings, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_add_event_cb(ui_Axis_Settings, ui_event_Axis_Settings, LV_EVENT_ALL, NULL);

    // Switch1

    ui_Switch1 = lv_switch_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Switch1, 50);
    lv_obj_set_height(ui_Switch1, 25);

    lv_obj_set_x(ui_Switch1, 137);
    lv_obj_set_y(ui_Switch1, 279);

    // Switch2

    ui_Switch2 = lv_switch_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Switch2, 50);
    lv_obj_set_height(ui_Switch2, 25);

    lv_obj_set_x(ui_Switch2, 329);
    lv_obj_set_y(ui_Switch2, 245);

    // Switch3

    ui_Switch3 = lv_switch_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Switch3, 50);
    lv_obj_set_height(ui_Switch3, 25);

    lv_obj_set_x(ui_Switch3, 329);
    lv_obj_set_y(ui_Switch3, 280);

    // Switch4

    ui_Switch4 = lv_switch_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Switch4, 50);
    lv_obj_set_height(ui_Switch4, 25);

    lv_obj_set_x(ui_Switch4, 137);
    lv_obj_set_y(ui_Switch4, 244);

    // Allow_Single_Axis

    ui_Allow_Single_Axis = lv_label_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Allow_Single_Axis, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Allow_Single_Axis, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Allow_Single_Axis, 200);
    lv_obj_set_y(ui_Allow_Single_Axis, 285);

    lv_label_set_text(ui_Allow_Single_Axis, "Allow Single Axis:");

    // Positive_Direction

    ui_Positive_Direction = lv_label_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Positive_Direction, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Positive_Direction, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Positive_Direction, 193);
    lv_obj_set_y(ui_Positive_Direction, 251);

    lv_label_set_text(ui_Positive_Direction, "Positive Direction:");

    // Soft_Limits_copy_copy

    ui_Soft_Limits_copy_copy = lv_label_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Soft_Limits_copy_copy, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Soft_Limits_copy_copy, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Soft_Limits_copy_copy, 53);
    lv_obj_set_y(ui_Soft_Limits_copy_copy, 282);

    lv_label_set_text(ui_Soft_Limits_copy_copy, "Soft Limits:");

    // Hard_Limits

    ui_Hard_Limits = lv_label_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Hard_Limits, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Hard_Limits, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Hard_Limits, 46);
    lv_obj_set_y(ui_Hard_Limits, 249);

    lv_label_set_text(ui_Hard_Limits, "Hard Limits:");

    // TextArea2

    ui_TextArea2 = lv_textarea_create(ui_Axis_Settings);

    lv_obj_set_width(ui_TextArea2, 92);
    lv_obj_set_height(ui_TextArea2, 39);

    lv_obj_set_x(ui_TextArea2, 136);
    lv_obj_set_y(ui_TextArea2, 55);

    if("" == "") lv_textarea_set_accepted_chars(ui_TextArea2, NULL);
    else lv_textarea_set_accepted_chars(ui_TextArea2, "");

    lv_textarea_set_max_length(ui_TextArea2, 9);
    lv_textarea_set_text(ui_TextArea2, "18000.500");
    lv_textarea_set_placeholder_text(ui_TextArea2, "Placeholder...");
    lv_textarea_set_one_line(ui_TextArea2, true);

    lv_obj_add_flag(ui_TextArea2, LV_OBJ_FLAG_FLOATING);
    lv_obj_clear_flag(ui_TextArea2, LV_OBJ_FLAG_PRESS_LOCK | LV_OBJ_FLAG_GESTURE_BUBBLE | LV_OBJ_FLAG_SNAPPABLE |
                      LV_OBJ_FLAG_SCROLLABLE | LV_OBJ_FLAG_SCROLL_ELASTIC | LV_OBJ_FLAG_SCROLL_MOMENTUM | LV_OBJ_FLAG_SCROLL_CHAIN);

    lv_obj_set_scrollbar_mode(ui_TextArea2, LV_SCROLLBAR_MODE_ON);

    lv_obj_add_event_cb(ui_TextArea2, ui_event_TextArea2, LV_EVENT_ALL, NULL);

    // TextArea2_copy

    ui_TextArea2_copy = lv_textarea_create(ui_Axis_Settings);

    lv_obj_set_width(ui_TextArea2_copy, 92);
    lv_obj_set_height(ui_TextArea2_copy, 39);

    lv_obj_set_x(ui_TextArea2_copy, 375);
    lv_obj_set_y(ui_TextArea2_copy, 55);

    if("" == "") lv_textarea_set_accepted_chars(ui_TextArea2_copy, NULL);
    else lv_textarea_set_accepted_chars(ui_TextArea2_copy, "");

    lv_textarea_set_max_length(ui_TextArea2_copy, 9);
    lv_textarea_set_text(ui_TextArea2_copy, "18000.500");
    lv_textarea_set_placeholder_text(ui_TextArea2_copy, "Placeholder...");
    lv_textarea_set_one_line(ui_TextArea2_copy, true);

    lv_obj_add_flag(ui_TextArea2_copy, LV_OBJ_FLAG_FLOATING);
    lv_obj_clear_flag(ui_TextArea2_copy,
                      LV_OBJ_FLAG_PRESS_LOCK | LV_OBJ_FLAG_GESTURE_BUBBLE | LV_OBJ_FLAG_SNAPPABLE | LV_OBJ_FLAG_SCROLLABLE |
                      LV_OBJ_FLAG_SCROLL_ELASTIC | LV_OBJ_FLAG_SCROLL_MOMENTUM | LV_OBJ_FLAG_SCROLL_CHAIN);

    lv_obj_set_scrollbar_mode(ui_TextArea2_copy, LV_SCROLLBAR_MODE_ON);

    lv_obj_add_event_cb(ui_TextArea2_copy, ui_event_TextArea2_copy, LV_EVENT_ALL, NULL);

    // TextArea2_copy_copy

    ui_TextArea2_copy_copy = lv_textarea_create(ui_Axis_Settings);

    lv_obj_set_width(ui_TextArea2_copy_copy, 92);
    lv_obj_set_height(ui_TextArea2_copy_copy, 39);

    lv_obj_set_x(ui_TextArea2_copy_copy, 374);
    lv_obj_set_y(ui_TextArea2_copy_copy, 102);

    if("" == "") lv_textarea_set_accepted_chars(ui_TextArea2_copy_copy, NULL);
    else lv_textarea_set_accepted_chars(ui_TextArea2_copy_copy, "");

    lv_textarea_set_max_length(ui_TextArea2_copy_copy, 9);
    lv_textarea_set_text(ui_TextArea2_copy_copy, "18000.500");
    lv_textarea_set_placeholder_text(ui_TextArea2_copy_copy, "Placeholder...");
    lv_textarea_set_one_line(ui_TextArea2_copy_copy, true);

    lv_obj_add_flag(ui_TextArea2_copy_copy, LV_OBJ_FLAG_FLOATING);
    lv_obj_clear_flag(ui_TextArea2_copy_copy,
                      LV_OBJ_FLAG_PRESS_LOCK | LV_OBJ_FLAG_GESTURE_BUBBLE | LV_OBJ_FLAG_SNAPPABLE | LV_OBJ_FLAG_SCROLLABLE |
                      LV_OBJ_FLAG_SCROLL_ELASTIC | LV_OBJ_FLAG_SCROLL_MOMENTUM | LV_OBJ_FLAG_SCROLL_CHAIN);

    lv_obj_set_scrollbar_mode(ui_TextArea2_copy_copy, LV_SCROLLBAR_MODE_ON);

    lv_obj_add_event_cb(ui_TextArea2_copy_copy, ui_event_TextArea2_copy_copy, LV_EVENT_ALL, NULL);

    // TextArea2_copy_copy_copy

    ui_TextArea2_copy_copy_copy = lv_textarea_create(ui_Axis_Settings);

    lv_obj_set_width(ui_TextArea2_copy_copy_copy, 92);
    lv_obj_set_height(ui_TextArea2_copy_copy_copy, 39);

    lv_obj_set_x(ui_TextArea2_copy_copy_copy, 374);
    lv_obj_set_y(ui_TextArea2_copy_copy_copy, 148);

    if("" == "") lv_textarea_set_accepted_chars(ui_TextArea2_copy_copy_copy, NULL);
    else lv_textarea_set_accepted_chars(ui_TextArea2_copy_copy_copy, "");

    lv_textarea_set_max_length(ui_TextArea2_copy_copy_copy, 9);
    lv_textarea_set_text(ui_TextArea2_copy_copy_copy, "18000.500");
    lv_textarea_set_placeholder_text(ui_TextArea2_copy_copy_copy, "Placeholder...");
    lv_textarea_set_one_line(ui_TextArea2_copy_copy_copy, true);

    lv_obj_add_flag(ui_TextArea2_copy_copy_copy, LV_OBJ_FLAG_FLOATING);
    lv_obj_clear_flag(ui_TextArea2_copy_copy_copy,
                      LV_OBJ_FLAG_PRESS_LOCK | LV_OBJ_FLAG_GESTURE_BUBBLE | LV_OBJ_FLAG_SNAPPABLE | LV_OBJ_FLAG_SCROLLABLE |
                      LV_OBJ_FLAG_SCROLL_ELASTIC | LV_OBJ_FLAG_SCROLL_MOMENTUM | LV_OBJ_FLAG_SCROLL_CHAIN);

    lv_obj_set_scrollbar_mode(ui_TextArea2_copy_copy_copy, LV_SCROLLBAR_MODE_ON);

    lv_obj_add_event_cb(ui_TextArea2_copy_copy_copy, ui_event_TextArea2_copy_copy_copy, LV_EVENT_ALL, NULL);

    // TextArea2_copy_copy_copy_copy

    ui_TextArea2_copy_copy_copy_copy = lv_textarea_create(ui_Axis_Settings);

    lv_obj_set_width(ui_TextArea2_copy_copy_copy_copy, 92);
    lv_obj_set_height(ui_TextArea2_copy_copy_copy_copy, 39);

    lv_obj_set_x(ui_TextArea2_copy_copy_copy_copy, 374);
    lv_obj_set_y(ui_TextArea2_copy_copy_copy_copy, 194);

    if("" == "") lv_textarea_set_accepted_chars(ui_TextArea2_copy_copy_copy_copy, NULL);
    else lv_textarea_set_accepted_chars(ui_TextArea2_copy_copy_copy_copy, "");

    lv_textarea_set_max_length(ui_TextArea2_copy_copy_copy_copy, 9);
    lv_textarea_set_text(ui_TextArea2_copy_copy_copy_copy, "18000.500");
    lv_textarea_set_placeholder_text(ui_TextArea2_copy_copy_copy_copy, "Placeholder...");
    lv_textarea_set_one_line(ui_TextArea2_copy_copy_copy_copy, true);

    lv_obj_add_flag(ui_TextArea2_copy_copy_copy_copy, LV_OBJ_FLAG_FLOATING);
    lv_obj_clear_flag(ui_TextArea2_copy_copy_copy_copy,
                      LV_OBJ_FLAG_PRESS_LOCK | LV_OBJ_FLAG_GESTURE_BUBBLE | LV_OBJ_FLAG_SNAPPABLE | LV_OBJ_FLAG_SCROLLABLE |
                      LV_OBJ_FLAG_SCROLL_ELASTIC | LV_OBJ_FLAG_SCROLL_MOMENTUM | LV_OBJ_FLAG_SCROLL_CHAIN);

    lv_obj_set_scrollbar_mode(ui_TextArea2_copy_copy_copy_copy, LV_SCROLLBAR_MODE_ON);

    lv_obj_add_event_cb(ui_TextArea2_copy_copy_copy_copy, ui_event_TextArea2_copy_copy_copy_copy, LV_EVENT_ALL, NULL);

    // TextArea2_3

    ui_TextArea2_3 = lv_textarea_create(ui_Axis_Settings);

    lv_obj_set_width(ui_TextArea2_3, 92);
    lv_obj_set_height(ui_TextArea2_3, 39);

    lv_obj_set_x(ui_TextArea2_3, 136);
    lv_obj_set_y(ui_TextArea2_3, 102);

    if("" == "") lv_textarea_set_accepted_chars(ui_TextArea2_3, NULL);
    else lv_textarea_set_accepted_chars(ui_TextArea2_3, "");

    lv_textarea_set_max_length(ui_TextArea2_3, 9);
    lv_textarea_set_text(ui_TextArea2_3, "18000.500");
    lv_textarea_set_placeholder_text(ui_TextArea2_3, "Placeholder...");
    lv_textarea_set_one_line(ui_TextArea2_3, true);

    lv_obj_add_flag(ui_TextArea2_3, LV_OBJ_FLAG_FLOATING);
    lv_obj_clear_flag(ui_TextArea2_3, LV_OBJ_FLAG_PRESS_LOCK | LV_OBJ_FLAG_GESTURE_BUBBLE | LV_OBJ_FLAG_SNAPPABLE |
                      LV_OBJ_FLAG_SCROLLABLE | LV_OBJ_FLAG_SCROLL_ELASTIC | LV_OBJ_FLAG_SCROLL_MOMENTUM | LV_OBJ_FLAG_SCROLL_CHAIN);

    lv_obj_set_scrollbar_mode(ui_TextArea2_3, LV_SCROLLBAR_MODE_ON);

    lv_obj_add_event_cb(ui_TextArea2_3, ui_event_TextArea2_3, LV_EVENT_ALL, NULL);

    // TextArea2_2

    ui_TextArea2_2 = lv_textarea_create(ui_Axis_Settings);

    lv_obj_set_width(ui_TextArea2_2, 92);
    lv_obj_set_height(ui_TextArea2_2, 39);

    lv_obj_set_x(ui_TextArea2_2, 137);
    lv_obj_set_y(ui_TextArea2_2, 148);

    if("" == "") lv_textarea_set_accepted_chars(ui_TextArea2_2, NULL);
    else lv_textarea_set_accepted_chars(ui_TextArea2_2, "");

    lv_textarea_set_max_length(ui_TextArea2_2, 9);
    lv_textarea_set_text(ui_TextArea2_2, "18000.500");
    lv_textarea_set_placeholder_text(ui_TextArea2_2, "Placeholder...");
    lv_textarea_set_one_line(ui_TextArea2_2, true);

    lv_obj_add_flag(ui_TextArea2_2, LV_OBJ_FLAG_FLOATING);
    lv_obj_clear_flag(ui_TextArea2_2, LV_OBJ_FLAG_PRESS_LOCK | LV_OBJ_FLAG_GESTURE_BUBBLE | LV_OBJ_FLAG_SNAPPABLE |
                      LV_OBJ_FLAG_SCROLLABLE | LV_OBJ_FLAG_SCROLL_ELASTIC | LV_OBJ_FLAG_SCROLL_MOMENTUM | LV_OBJ_FLAG_SCROLL_CHAIN);

    lv_obj_set_scrollbar_mode(ui_TextArea2_2, LV_SCROLLBAR_MODE_ON);

    lv_obj_add_event_cb(ui_TextArea2_2, ui_event_TextArea2_2, LV_EVENT_ALL, NULL);

    // TextArea2_1

    ui_TextArea2_1 = lv_textarea_create(ui_Axis_Settings);

    lv_obj_set_width(ui_TextArea2_1, 92);
    lv_obj_set_height(ui_TextArea2_1, 39);

    lv_obj_set_x(ui_TextArea2_1, 137);
    lv_obj_set_y(ui_TextArea2_1, 194);

    if("" == "") lv_textarea_set_accepted_chars(ui_TextArea2_1, NULL);
    else lv_textarea_set_accepted_chars(ui_TextArea2_1, "");

    lv_textarea_set_max_length(ui_TextArea2_1, 9);
    lv_textarea_set_text(ui_TextArea2_1, "18000.500");
    lv_textarea_set_placeholder_text(ui_TextArea2_1, "Placeholder...");
    lv_textarea_set_one_line(ui_TextArea2_1, true);

    lv_obj_add_flag(ui_TextArea2_1, LV_OBJ_FLAG_FLOATING);
    lv_obj_clear_flag(ui_TextArea2_1, LV_OBJ_FLAG_PRESS_LOCK | LV_OBJ_FLAG_GESTURE_BUBBLE | LV_OBJ_FLAG_SNAPPABLE |
                      LV_OBJ_FLAG_SCROLLABLE | LV_OBJ_FLAG_SCROLL_ELASTIC | LV_OBJ_FLAG_SCROLL_MOMENTUM | LV_OBJ_FLAG_SCROLL_CHAIN);

    lv_obj_set_scrollbar_mode(ui_TextArea2_1, LV_SCROLLBAR_MODE_ON);

    lv_obj_add_event_cb(ui_TextArea2_1, ui_event_TextArea2_1, LV_EVENT_ALL, NULL);

    // Label13

    ui_Label13 = lv_label_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Label13, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label13, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label13, 0);
    lv_obj_set_y(ui_Label13, 1);

    lv_obj_set_align(ui_Label13, LV_ALIGN_TOP_MID);

    lv_label_set_text(ui_Label13, "X Axis Settings");

    lv_obj_set_style_text_font(ui_Label13, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Label14

    ui_Label14 = lv_label_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Label14, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label14, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label14, 67);
    lv_obj_set_y(ui_Label14, 70);

    lv_label_set_text(ui_Label14, "Steps:");

    // Label14_copy

    ui_Label14_copy = lv_label_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Label14_copy, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label14_copy, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label14_copy, 71);
    lv_obj_set_y(ui_Label14_copy, 113);

    lv_label_set_text(ui_Label14_copy, "Feed:");

    // Label14_copy_copy

    ui_Label14_copy_copy = lv_label_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Label14_copy_copy, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label14_copy_copy, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label14_copy_copy, 69);
    lv_obj_set_y(ui_Label14_copy_copy, 209);

    lv_label_set_text(ui_Label14_copy_copy, "Travel:");

    // Label14_copy_copy1

    ui_Label14_copy_copy1 = lv_label_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Label14_copy_copy1, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label14_copy_copy1, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label14_copy_copy1, 69);
    lv_obj_set_y(ui_Label14_copy_copy1, 159);

    lv_label_set_text(ui_Label14_copy_copy1, "Accel:");

    // Label14_copy1

    ui_Label14_copy1 = lv_label_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Label14_copy1, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label14_copy1, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label14_copy1, 313);
    lv_obj_set_y(ui_Label14_copy1, 70);

    lv_label_set_text(ui_Label14_copy1, "MPos:");

    // Label14_copy1_copy

    ui_Label14_copy1_copy = lv_label_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Label14_copy1_copy, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label14_copy1_copy, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label14_copy1_copy, 312);
    lv_obj_set_y(ui_Label14_copy1_copy, 113);

    lv_label_set_text(ui_Label14_copy1_copy, "Feed:");

    // Label14_copy1_copy_copy

    ui_Label14_copy1_copy_copy = lv_label_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Label14_copy1_copy_copy, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label14_copy1_copy_copy, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label14_copy1_copy_copy, 312);
    lv_obj_set_y(ui_Label14_copy1_copy_copy, 159);

    lv_label_set_text(ui_Label14_copy1_copy_copy, "Seek:");

    // Label14_copy1_copy_copy_copy

    ui_Label14_copy1_copy_copy_copy = lv_label_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Label14_copy1_copy_copy_copy, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label14_copy1_copy_copy_copy, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label14_copy1_copy_copy_copy, 302);
    lv_obj_set_y(ui_Label14_copy1_copy_copy_copy, 209);

    lv_label_set_text(ui_Label14_copy1_copy_copy_copy, "Pulloff:");

    // Label21

    ui_Label21 = lv_label_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Label21, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label21, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label21, 179);
    lv_obj_set_y(ui_Label21, -123);

    lv_obj_set_align(ui_Label21, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label21, "Homing:");

    // Keyboard2

    ui_Keyboard2 = lv_keyboard_create(ui_Axis_Settings);

    lv_keyboard_set_mode(ui_Keyboard2, LV_KEYBOARD_MODE_NUMBER);

    lv_obj_set_width(ui_Keyboard2, 300);
    lv_obj_set_height(ui_Keyboard2, 120);

    lv_obj_set_x(ui_Keyboard2, 0);
    lv_obj_set_y(ui_Keyboard2, 0);

    lv_obj_set_align(ui_Keyboard2, LV_ALIGN_CENTER);

    lv_obj_add_flag(ui_Keyboard2, LV_OBJ_FLAG_HIDDEN);

    // ImgButton3_copy_copy

    ui_ImgButton3_copy_copy = lv_imgbtn_create(ui_Axis_Settings);
    lv_imgbtn_set_src(ui_ImgButton3_copy_copy, LV_IMGBTN_STATE_RELEASED, NULL, &ui_img_back1_png, NULL);
    lv_imgbtn_set_src(ui_ImgButton3_copy_copy, LV_IMGBTN_STATE_PRESSED, NULL, &ui_img_back1_png, NULL);

    lv_obj_set_height(ui_ImgButton3_copy_copy, 64);
    lv_obj_set_width(ui_ImgButton3_copy_copy, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_ImgButton3_copy_copy, 8);
    lv_obj_set_y(ui_ImgButton3_copy_copy, 8);

    lv_obj_add_event_cb(ui_ImgButton3_copy_copy, ui_event_ImgButton3_copy_copy, LV_EVENT_ALL, NULL);

    // Button6

    ui_Button6 = lv_btn_create(ui_Axis_Settings);

    lv_obj_set_width(ui_Button6, 60);
    lv_obj_set_height(ui_Button6, 50);

    lv_obj_set_x(ui_Button6, 191);
    lv_obj_set_y(ui_Button6, 117);

    lv_obj_set_align(ui_Button6, LV_ALIGN_CENTER);

    lv_obj_add_flag(ui_Button6, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button6, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_add_event_cb(ui_Button6, ui_event_Button6, LV_EVENT_ALL, NULL);

    // Label51

    ui_Label51 = lv_label_create(ui_Button6);

    lv_obj_set_width(ui_Label51, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label51, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label51, 0);
    lv_obj_set_y(ui_Label51, 0);

    lv_obj_set_align(ui_Label51, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label51, "Save");

    // POST CALLS
    lv_keyboard_set_textarea(ui_Keyboard2, ui_TextArea2);

}
void ui_Move_Axis_screen_init(void)
{

    // Move_Axis

    ui_Move_Axis = lv_obj_create(NULL);

    lv_obj_clear_flag(ui_Move_Axis, LV_OBJ_FLAG_SCROLLABLE);

    // Label22

    ui_Label22 = lv_label_create(ui_Move_Axis);

    lv_obj_set_width(ui_Label22, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label22, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label22, 0);
    lv_obj_set_y(ui_Label22, 1);

    lv_obj_set_align(ui_Label22, LV_ALIGN_TOP_MID);

    lv_label_set_text(ui_Label22, "Move Axis");

    lv_obj_set_style_text_font(ui_Label22, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Button3

    ui_Button3 = lv_btn_create(ui_Move_Axis);

    lv_obj_set_width(ui_Button3, 60);
    lv_obj_set_height(ui_Button3, 50);

    lv_obj_set_x(ui_Button3, 20);
    lv_obj_set_y(ui_Button3, 83);

    lv_obj_add_flag(ui_Button3, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button3, LV_OBJ_FLAG_SCROLLABLE);

    // Label23

    ui_Label23 = lv_label_create(ui_Button3);

    lv_obj_set_width(ui_Label23, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label23, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label23, 0);
    lv_obj_set_y(ui_Label23, 0);

    lv_obj_set_align(ui_Label23, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label23, "X+");

    lv_obj_set_style_text_font(ui_Label23, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Button3_copy

    ui_Button3_copy = lv_btn_create(ui_Move_Axis);

    lv_obj_set_width(ui_Button3_copy, 60);
    lv_obj_set_height(ui_Button3_copy, 50);

    lv_obj_set_x(ui_Button3_copy, 100);
    lv_obj_set_y(ui_Button3_copy, 83);

    lv_obj_add_flag(ui_Button3_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button3_copy, LV_OBJ_FLAG_SCROLLABLE);

    // Label24

    ui_Label24 = lv_label_create(ui_Button3_copy);

    lv_obj_set_width(ui_Label24, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label24, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label24, 0);
    lv_obj_set_y(ui_Label24, 0);

    lv_obj_set_align(ui_Label24, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label24, "X-");

    lv_obj_set_style_text_font(ui_Label24, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Button3_copy1

    ui_Button3_copy1 = lv_btn_create(ui_Move_Axis);

    lv_obj_set_width(ui_Button3_copy1, 60);
    lv_obj_set_height(ui_Button3_copy1, 50);

    lv_obj_set_x(ui_Button3_copy1, 20);
    lv_obj_set_y(ui_Button3_copy1, 150);

    lv_obj_add_flag(ui_Button3_copy1, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button3_copy1, LV_OBJ_FLAG_SCROLLABLE);

    // Label25

    ui_Label25 = lv_label_create(ui_Button3_copy1);

    lv_obj_set_width(ui_Label25, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label25, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label25, 0);
    lv_obj_set_y(ui_Label25, 0);

    lv_obj_set_align(ui_Label25, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label25, "Y+");

    lv_obj_set_style_text_font(ui_Label25, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Button3_copy1_copy

    ui_Button3_copy1_copy = lv_btn_create(ui_Move_Axis);

    lv_obj_set_width(ui_Button3_copy1_copy, 60);
    lv_obj_set_height(ui_Button3_copy1_copy, 50);

    lv_obj_set_x(ui_Button3_copy1_copy, 20);
    lv_obj_set_y(ui_Button3_copy1_copy, 213);

    lv_obj_add_flag(ui_Button3_copy1_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button3_copy1_copy, LV_OBJ_FLAG_SCROLLABLE);

    // Label26

    ui_Label26 = lv_label_create(ui_Button3_copy1_copy);

    lv_obj_set_width(ui_Label26, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label26, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label26, 0);
    lv_obj_set_y(ui_Label26, 0);

    lv_obj_set_align(ui_Label26, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label26, "Z+");

    lv_obj_set_style_text_font(ui_Label26, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Button3_copy_copy

    ui_Button3_copy_copy = lv_btn_create(ui_Move_Axis);

    lv_obj_set_width(ui_Button3_copy_copy, 60);
    lv_obj_set_height(ui_Button3_copy_copy, 50);

    lv_obj_set_x(ui_Button3_copy_copy, 100);
    lv_obj_set_y(ui_Button3_copy_copy, 150);

    lv_obj_add_flag(ui_Button3_copy_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button3_copy_copy, LV_OBJ_FLAG_SCROLLABLE);

    // Label27

    ui_Label27 = lv_label_create(ui_Button3_copy_copy);

    lv_obj_set_width(ui_Label27, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label27, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label27, 0);
    lv_obj_set_y(ui_Label27, 0);

    lv_obj_set_align(ui_Label27, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label27, "Y-");

    lv_obj_set_style_text_font(ui_Label27, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Button3_copy_copy_copy

    ui_Button3_copy_copy_copy = lv_btn_create(ui_Move_Axis);

    lv_obj_set_width(ui_Button3_copy_copy_copy, 60);
    lv_obj_set_height(ui_Button3_copy_copy_copy, 50);

    lv_obj_set_x(ui_Button3_copy_copy_copy, 100);
    lv_obj_set_y(ui_Button3_copy_copy_copy, 213);

    lv_obj_add_flag(ui_Button3_copy_copy_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button3_copy_copy_copy, LV_OBJ_FLAG_SCROLLABLE);

    // Label28

    ui_Label28 = lv_label_create(ui_Button3_copy_copy_copy);

    lv_obj_set_width(ui_Label28, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label28, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label28, 0);
    lv_obj_set_y(ui_Label28, 0);

    lv_obj_set_align(ui_Label28, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label28, "Z-");

    lv_obj_set_style_text_font(ui_Label28, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Switch5

    ui_Switch5 = lv_switch_create(ui_Move_Axis);

    lv_obj_set_width(ui_Switch5, 50);
    lv_obj_set_height(ui_Switch5, 25);

    lv_obj_set_x(ui_Switch5, 106);
    lv_obj_set_y(ui_Switch5, 281);

    // Label30

    ui_Label30 = lv_label_create(ui_Move_Axis);

    lv_obj_set_width(ui_Label30, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label30, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label30, 16);
    lv_obj_set_y(ui_Label30, 285);

    lv_label_set_text(ui_Label30, "Jog Modus:");

    // Button4

    ui_Button4 = lv_btn_create(ui_Move_Axis);

    lv_obj_set_width(ui_Button4, 65);
    lv_obj_set_height(ui_Button4, 50);

    lv_obj_set_x(ui_Button4, 400);
    lv_obj_set_y(ui_Button4, 213);

    lv_obj_add_flag(ui_Button4, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button4, LV_OBJ_FLAG_SCROLLABLE);

    // Label31

    ui_Label31 = lv_label_create(ui_Button4);

    lv_obj_set_width(ui_Label31, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label31, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label31, 0);
    lv_obj_set_y(ui_Label31, 0);

    lv_obj_set_align(ui_Label31, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label31, "F10000");

    // Button4_1

    ui_Button4_1 = lv_btn_create(ui_Move_Axis);

    lv_obj_set_width(ui_Button4_1, 65);
    lv_obj_set_height(ui_Button4_1, 50);

    lv_obj_set_x(ui_Button4_1, 315);
    lv_obj_set_y(ui_Button4_1, 213);

    lv_obj_add_flag(ui_Button4_1, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button4_1, LV_OBJ_FLAG_SCROLLABLE);

    // Label32

    ui_Label32 = lv_label_create(ui_Button4_1);

    lv_obj_set_width(ui_Label32, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label32, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label32, 0);
    lv_obj_set_y(ui_Label32, 0);

    lv_obj_set_align(ui_Label32, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label32, "50 mm");

    // Button4_2

    ui_Button4_2 = lv_btn_create(ui_Move_Axis);

    lv_obj_set_width(ui_Button4_2, 65);
    lv_obj_set_height(ui_Button4_2, 50);

    lv_obj_set_x(ui_Button4_2, 315);
    lv_obj_set_y(ui_Button4_2, 83);

    lv_obj_add_flag(ui_Button4_2, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button4_2, LV_OBJ_FLAG_SCROLLABLE);

    // Label33

    ui_Label33 = lv_label_create(ui_Button4_2);

    lv_obj_set_width(ui_Label33, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label33, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label33, 0);
    lv_obj_set_y(ui_Label33, 0);

    lv_obj_set_align(ui_Label33, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label33, "1 mm");

    // Button4_copy_copy_copy

    ui_Button4_copy_copy_copy = lv_btn_create(ui_Move_Axis);

    lv_obj_set_width(ui_Button4_copy_copy_copy, 65);
    lv_obj_set_height(ui_Button4_copy_copy_copy, 50);

    lv_obj_set_x(ui_Button4_copy_copy_copy, 400);
    lv_obj_set_y(ui_Button4_copy_copy_copy, 83);

    lv_obj_add_flag(ui_Button4_copy_copy_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button4_copy_copy_copy, LV_OBJ_FLAG_SCROLLABLE);

    // Label34

    ui_Label34 = lv_label_create(ui_Button4_copy_copy_copy);

    lv_obj_set_width(ui_Label34, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label34, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label34, 0);
    lv_obj_set_y(ui_Label34, 0);

    lv_obj_set_align(ui_Label34, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label34, "F500");

    // Button4_5

    ui_Button4_5 = lv_btn_create(ui_Move_Axis);

    lv_obj_set_width(ui_Button4_5, 65);
    lv_obj_set_height(ui_Button4_5, 50);

    lv_obj_set_x(ui_Button4_5, 315);
    lv_obj_set_y(ui_Button4_5, 150);

    lv_obj_add_flag(ui_Button4_5, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button4_5, LV_OBJ_FLAG_SCROLLABLE);

    // Label35

    ui_Label35 = lv_label_create(ui_Button4_5);

    lv_obj_set_width(ui_Label35, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label35, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label35, 0);
    lv_obj_set_y(ui_Label35, 0);

    lv_obj_set_align(ui_Label35, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label35, "5 mm");

    // Button4_copy_copy_copy_copy_copy

    ui_Button4_copy_copy_copy_copy_copy = lv_btn_create(ui_Move_Axis);

    lv_obj_set_width(ui_Button4_copy_copy_copy_copy_copy, 65);
    lv_obj_set_height(ui_Button4_copy_copy_copy_copy_copy, 50);

    lv_obj_set_x(ui_Button4_copy_copy_copy_copy_copy, 400);
    lv_obj_set_y(ui_Button4_copy_copy_copy_copy_copy, 150);

    lv_obj_add_flag(ui_Button4_copy_copy_copy_copy_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button4_copy_copy_copy_copy_copy, LV_OBJ_FLAG_SCROLLABLE);

    // Label36

    ui_Label36 = lv_label_create(ui_Button4_copy_copy_copy_copy_copy);

    lv_obj_set_width(ui_Label36, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label36, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label36, 0);
    lv_obj_set_y(ui_Label36, 0);

    lv_obj_set_align(ui_Label36, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label36, "F1000");

    // Label37

    ui_Label37 = lv_label_create(ui_Move_Axis);

    lv_obj_set_width(ui_Label37, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label37, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label37, 197);
    lv_obj_set_y(ui_Label37, 285);

    lv_label_set_text(ui_Label37, "X:");

    // Label37_copy

    ui_Label37_copy = lv_label_create(ui_Move_Axis);

    lv_obj_set_width(ui_Label37_copy, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label37_copy, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label37_copy, 292);
    lv_obj_set_y(ui_Label37_copy, 285);

    lv_label_set_text(ui_Label37_copy, "Y:");

    // Label37_copy1

    ui_Label37_copy1 = lv_label_create(ui_Move_Axis);

    lv_obj_set_width(ui_Label37_copy1, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label37_copy1, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label37_copy1, 389);
    lv_obj_set_y(ui_Label37_copy1, 285);

    lv_label_set_text(ui_Label37_copy1, "Z:");

    // Button4_2_copy

    ui_Button4_2_copy = lv_btn_create(ui_Move_Axis);

    lv_obj_set_width(ui_Button4_2_copy, 65);
    lv_obj_set_height(ui_Button4_2_copy, 50);

    lv_obj_set_x(ui_Button4_2_copy, 204);
    lv_obj_set_y(ui_Button4_2_copy, 83);

    lv_obj_add_flag(ui_Button4_2_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button4_2_copy, LV_OBJ_FLAG_SCROLLABLE);

    // Label38

    ui_Label38 = lv_label_create(ui_Button4_2_copy);

    lv_obj_set_width(ui_Label38, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label38, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label38, 0);
    lv_obj_set_y(ui_Label38, 0);

    lv_obj_set_align(ui_Label38, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label38, "Home\n   all");

    // Button4_2_copy_copy

    ui_Button4_2_copy_copy = lv_btn_create(ui_Move_Axis);

    lv_obj_set_width(ui_Button4_2_copy_copy, 65);
    lv_obj_set_height(ui_Button4_2_copy_copy, 50);

    lv_obj_set_x(ui_Button4_2_copy_copy, 204);
    lv_obj_set_y(ui_Button4_2_copy_copy, 150);

    lv_obj_add_flag(ui_Button4_2_copy_copy, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_Button4_2_copy_copy, LV_OBJ_FLAG_SCROLLABLE);

    // Label39

    ui_Label39 = lv_label_create(ui_Button4_2_copy_copy);

    lv_obj_set_width(ui_Label39, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label39, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label39, 0);
    lv_obj_set_y(ui_Label39, 0);

    lv_obj_set_align(ui_Label39, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label39, "Motors\n    off");

    // Label40

    ui_Label40 = lv_label_create(ui_Move_Axis);

    lv_obj_set_width(ui_Label40, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label40, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label40, 211);
    lv_obj_set_y(ui_Label40, 285);

    lv_label_set_text(ui_Label40, "123.123");

    // Label41

    ui_Label41 = lv_label_create(ui_Move_Axis);

    lv_obj_set_width(ui_Label41, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label41, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label41, 307);
    lv_obj_set_y(ui_Label41, 285);

    lv_label_set_text(ui_Label41, "123.123");

    // Label42

    ui_Label42 = lv_label_create(ui_Move_Axis);

    lv_obj_set_width(ui_Label42, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label42, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label42, 403);
    lv_obj_set_y(ui_Label42, 285);

    lv_label_set_text(ui_Label42, "123.123");

    // ImgButton3

    ui_ImgButton3 = lv_imgbtn_create(ui_Move_Axis);
    lv_imgbtn_set_src(ui_ImgButton3, LV_IMGBTN_STATE_RELEASED, NULL, &ui_img_back1_png, NULL);
    lv_imgbtn_set_src(ui_ImgButton3, LV_IMGBTN_STATE_PRESSED, NULL, &ui_img_back1_png, NULL);

    lv_obj_set_height(ui_ImgButton3, 64);
    lv_obj_set_width(ui_ImgButton3, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_ImgButton3, 8);
    lv_obj_set_y(ui_ImgButton3, 8);

    lv_obj_add_event_cb(ui_ImgButton3, ui_event_ImgButton3, LV_EVENT_ALL, NULL);

}
void ui_SD_Print_screen_init(void)
{

    // SD_Print

    ui_SD_Print = lv_obj_create(NULL);

    lv_obj_clear_flag(ui_SD_Print, LV_OBJ_FLAG_SCROLLABLE);

    // Label22_copy1

    ui_Label22_copy1 = lv_label_create(ui_SD_Print);

    lv_obj_set_width(ui_Label22_copy1, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label22_copy1, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label22_copy1, 0);
    lv_obj_set_y(ui_Label22_copy1, 1);

    lv_obj_set_align(ui_Label22_copy1, LV_ALIGN_TOP_MID);

    lv_label_set_text(ui_Label22_copy1, "SD Card");

    lv_obj_set_style_text_font(ui_Label22_copy1, &lv_font_montserrat_30, LV_PART_MAIN | LV_STATE_DEFAULT);

    // Panel3

    ui_Panel3 = lv_obj_create(ui_SD_Print);

    lv_obj_set_width(ui_Panel3, 387);
    lv_obj_set_height(ui_Panel3, 234);

    lv_obj_set_x(ui_Panel3, 13);
    lv_obj_set_y(ui_Panel3, 76);

    lv_obj_clear_flag(ui_Panel3, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_set_style_bg_color(ui_Panel3, lv_color_hex(0xD9D9D9), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Panel3, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    // ImgButton3_copy

    ui_ImgButton3_copy = lv_imgbtn_create(ui_SD_Print);
    lv_imgbtn_set_src(ui_ImgButton3_copy, LV_IMGBTN_STATE_RELEASED, NULL, &ui_img_back1_png, NULL);
    lv_imgbtn_set_src(ui_ImgButton3_copy, LV_IMGBTN_STATE_PRESSED, NULL, &ui_img_back1_png, NULL);

    lv_obj_set_height(ui_ImgButton3_copy, 64);
    lv_obj_set_width(ui_ImgButton3_copy, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_ImgButton3_copy, 8);
    lv_obj_set_y(ui_ImgButton3_copy, 8);

    lv_obj_add_event_cb(ui_ImgButton3_copy, ui_event_ImgButton3_copy, LV_EVENT_ALL, NULL);

    // up

    ui_up = lv_btn_create(ui_SD_Print);

    lv_obj_set_width(ui_up, 65);
    lv_obj_set_height(ui_up, 50);

    lv_obj_set_x(ui_up, 200);
    lv_obj_set_y(ui_up, -58);

    lv_obj_set_align(ui_up, LV_ALIGN_CENTER);

    lv_obj_add_flag(ui_up, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_up, LV_OBJ_FLAG_SCROLLABLE);

    // Label49

    ui_Label49 = lv_label_create(ui_up);

    lv_obj_set_width(ui_Label49, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label49, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label49, 0);
    lv_obj_set_y(ui_Label49, 0);

    lv_obj_set_align(ui_Label49, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label49, "Up");

    // down

    ui_down = lv_btn_create(ui_SD_Print);

    lv_obj_set_width(ui_down, 65);
    lv_obj_set_height(ui_down, 50);

    lv_obj_set_x(ui_down, 200);
    lv_obj_set_y(ui_down, 6);

    lv_obj_set_align(ui_down, LV_ALIGN_CENTER);

    lv_obj_add_flag(ui_down, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_down, LV_OBJ_FLAG_SCROLLABLE);

    // Label50

    ui_Label50 = lv_label_create(ui_down);

    lv_obj_set_width(ui_Label50, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label50, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label50, 0);
    lv_obj_set_y(ui_Label50, 0);

    lv_obj_set_align(ui_Label50, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label50, "Down");

    // print

    ui_print = lv_btn_create(ui_SD_Print);

    lv_obj_set_width(ui_print, 65);
    lv_obj_set_height(ui_print, 50);

    lv_obj_set_x(ui_print, 200);
    lv_obj_set_y(ui_print, 122);

    lv_obj_set_align(ui_print, LV_ALIGN_CENTER);

    lv_obj_add_flag(ui_print, LV_OBJ_FLAG_SCROLL_ON_FOCUS);
    lv_obj_clear_flag(ui_print, LV_OBJ_FLAG_SCROLLABLE);

    // Label48

    ui_Label48 = lv_label_create(ui_print);

    lv_obj_set_width(ui_Label48, LV_SIZE_CONTENT);
    lv_obj_set_height(ui_Label48, LV_SIZE_CONTENT);

    lv_obj_set_x(ui_Label48, 0);
    lv_obj_set_y(ui_Label48, 0);

    lv_obj_set_align(ui_Label48, LV_ALIGN_CENTER);

    lv_label_set_text(ui_Label48, "Run");

}

void ui_init(void)
{
    ui_Homescreen_screen_init();
    ui_Menus_screen_init();
    ui_Axis_Settings_screen_init();
    ui_Move_Axis_screen_init();
    ui_SD_Print_screen_init();
    lv_disp_load_scr(ui_Homescreen);
}

