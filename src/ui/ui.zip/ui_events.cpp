// SquareLine LVGL GENERATED FILE
// EDITOR VERSION: SquareLine Studio 1.0.1
// LVGL VERSION: 8.2
// PROJECT: FluidNC_Laser

#include <GxIO/STM32DUINO/GxIO_STM32F2_FSMC/GxIO_STM32F2_FSMC.h>
#include "ui.h"

void home_x(lv_event_t * e)
{
	Serial.println("$HX");
}

void home_y(lv_event_t * e)
{
Serial.println("$HY");
}

void home_all(lv_event_t * e)
{
Serial.println("$H");
}

void restart_esp(lv_event_t * e)
{
Serial.println("$bye");
}

void alarm_reset(lv_event_t * e)
{
Serial.println("$X");
}